/*
 * Copyright 2021 MindMotion Microelectronics Co., Ltd.
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */


#ifndef __SYSTEM_MM32F327X_H__
#define __SYSTEM_MM32F327X_H__

void SystemInit(void);

#endif /* __SYSTEM_MM32F327X_H__ */
